<?php
    require "dbc.php";

    if(isset($_POST['btn_upload'])){
		$img_id = $_GET["img_id"];
		$filetmp = $_FILES['file_img']['tmp_name'];
        $filename = $_FILES['file_img']['name'];
        $filetype = $_FILES['file_img']['type'];
        $filepath = 'img/'.$filename;
        $filetitle =  $_POST['img_title'];
        $filetags =  $_POST['img_tags'];
        $filetags2 =  $_POST['img_tags2'];


      
        move_uploaded_file($filetmp, $filepath);

		
        $query = "UPDATE tbl_photos3 SET img_path=?, img_title=?, img_tags=?, img_tags2=? WHERE img_id = ? ";
		$stmt = mysqli_prepare($conn, $query);
		$stmt->bind_param('sssss', $filepath, $filetitle,  $filetags, $filetags2, $img_id);
	
		
		if ($stmt->error) {
		  echo "FAILURE!!! " . $stmt->error;
		}
		
		else echo "เย้";
		
		$stmt->close();
    } 
?>


<html>
<head>
<title>ThaiCreate.Com Tutorial</title>


<link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css"> 
    <script src="js/bootstrap.min.js" integrity="" crossorigin="anonymous"></script>
</head>
<body>
<?php	

	
?>

	<button name="back" type="submit" value="Submit" id="" class="btn btn-primary">
                            <a href="index.php" style="color: #ffff; text-decoration:none;">
                                กลับไปหน้าก่อน
                            </a>
                        </button>
</body>
</html>