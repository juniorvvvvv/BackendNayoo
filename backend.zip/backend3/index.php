<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>โปรแกรมจัดการอัลบัมรูปภาพ</title>

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
     
</head>
<body>

    <div class="container-fluid">
            <div class="row">
                <div class="col-1">
    
                </div>
                <div class="col-10">

                   <nav> 

                        <div align=""><h2>อัลบัมรูปภาพ</h2></div>    
                        <a href="upload_photo.php" class="btn">
                           <button name="btnSubmit" type="submit" value="Submit" id="" class="btn btn-primary">
                                เพิ่มรูปภาพ
                            </button>
                        </a>
                   </nav>

                    <section class="photo">
                        <div class="container"> 
                            <div class="photo_grid">

                                    <?php 
                                        require 'dbc.php';
                                        $query = "SELECT * FROM tbl_photos3 ORDER BY img_id ASC";
                                        if($result = mysqli_query($conn, $query)){
                                            while($img = mysqli_fetch_array($result)){
                                                
                                            
                                        
                                    ?>
                            
                                <div class="photo_grid--items">
                                   

                                        <table class="table table-bordered">
                                            <tr>  
                                                <td><center>ชื่อภาพ : <?php echo $img["img_title"];?></center></td>
                                                <td ><center><a href="delete.php?img_id=<?php echo $img["img_id"];?>">Delete</a></center></td>
                                            </tr> 
                                            <tr> 
                                                <td><center>หมวดอัลบัม : <?php echo $img["img_tags"];?></center></td>
                                                <td></td>
                                            </tr>
                                            <tr> 
                                                <td><center>tags : <?php echo $img["img_tags2"];?></center></td>
                                                <td><center><a href="edit.php?img_id=<?php echo $img["img_id"];?>">Edit</a></center></td>
                                          
                                            </tr>

                                        </table>

                                        <a href="<?php echo $img['img_path']; ?>"  >
                                            <img src="<?php echo $img['img_path']; ?>" alt="">
                                        </a>
                                </div>

                                        <?php 
                                            }
                                                }
                                        ?>
                                
                            </div>
                        </div>
                    </section>

                </div>
            
                <div class="col-1">
                    
                </div>
            
            </div>
        
        </div>



</form>
</body>
</html>