<?php
    require "dbc.php";

    if(isset($_POST['btn_upload'])){
        $filetmp = $_FILES['file_img']['tmp_name'];
        $filename = $_FILES['file_img']['name'];
        $filetype = $_FILES['file_img']['type'];
        $filepath = 'img/'.$filename;
        $filetitle =  $_POST['img_title'];
        $filetags =  $_POST['img_tags'];
        $filetags2 =  $_POST['img_tags2'];


        move_uploaded_file($filetmp, $filepath);

        $query = "INSERT INTO tbl_photos3(img_name, img_type, img_path, img_title, img_tags, img_tags2) VALUES(?,?,?,?,?,?)";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "ssssss", $filename, $filetype, $filepath, $filetitle, $filetags, $filetags2);

        if(mysqli_stmt_execute($stmt)){
           header("Location: index.php");  
        }else{
            echo"Something Wrong!!";
        }
    } 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>โปรแกรมจัดการอัลบัมรูปภาพ</title>

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css"> 
    <script src="js/bootstrap.min.js" integrity="" crossorigin="anonymous"></script>

     
</head>
<body>

    <div class="container-fluid">
            <div class="row">
                <div class="col-1">
    
                </div>
                <div class="col-10">

                    <div align="center"><h2>โปรแกรมจัดการอัลบัมรูปภาพ</h2></div>     
                    <form action="" method="post" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label"> Name : </label>
                                    <input type="text" name="img_title" id="" class="form-control"  aria-describedby="">
                                    
                                    <div class="mb-3">
                                    <select name="img_tags" id="img_tags" class="form-select form-select-sm" style="height: 30px;" aria-label=".form-select-sm example">
                                        <option selected>เลือกหมวดอัลบัม</option>
                                        <option value="1">One</option>
                                        <option value="2">Two</option>                                        
                                    </select>
                                    </div>

                                    <label for="exampleInputEmail1" class="form-label"> Tag : </label>
                                    <input type="text" name="img_tags2" id="img_tags2" class="form-control"  aria-describedby="">

                                    <label for="exampleInputEmail1" class="form-label"> Picture : </label>
                                    <input type="file" name="file_img" id="file_img" class="form-control"  aria-describedby="">
                            </div>

                        <button name="btn_upload" type="submit" value="Submit" id="" class="btn btn-primary">
                                เพิ่มรูปภาพ
                        </button>
                

                        <button name="back" type="submit" value="Submit" id="" class="btn btn-primary">
                            <a href="index.php" style="color: #ffff; text-decoration:none;">
                                กลับไปหน้าแรก
                            </a>
                        </button>
                        
                    </form>

                    <section class="photo">
                        <div class="container"> 

                        </div>
                    </section>

                </div>
            
                <div class="col-1">
                    
                </div>
            
            </div>
        
        </div>



</form>
</body>
</html>