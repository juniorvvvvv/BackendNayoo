<html>
<head>


<link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
<title>ThaiCreate.Com Tutorial</title>
</head>
<body>

		<div class="container-fluid">
            <div class="row">
                <div class="col-1">
    
                </div>
                <div class="col-3">


					<?php
						require "dbc.php";

						$strSQL = "SELECT * FROM tbl_photos3 WHERE img_id = '".$_GET["img_id"]."' ";
						$objQuery = mysqli_query($conn, $strSQL) or die ("Error Query [".$strSQL."]");
						$objResult = mysqli_fetch_array($objQuery);
					?>

					<form name="form1" method="post" action="update.php?img_id=<?php echo $_GET["img_id"];?>" enctype="multipart/form-data">
						<div class="mb-3">
							<div align=""><h3>แก้ไขรูปภาพ</h3>   
						

								แก้ไข ชื่อ : 
								<input type="text" name="img_title" class="form-control" value="<?php echo $objResult["img_title"];?>" maxlength="100"><br>
                                    
								แก้ไข หมวด : 
									<select name="img_tags" id="img_tags" class="form-select form-select-sm" style="height: 30px;" aria-label=".form-select-sm example">
                                        <option selected>เลือกหมวดอัลบัม</option>
                                        <option value="1">One</option>
                                        <option value="2">Two</option>                                        
                                    </select>
								แก้ไข tag : 
								<input type="text" name="img_tags2" class="form-control" value="<?php echo $objResult["img_tags2"];?>" maxlength="100"><br>
							
								เปลี่ยนรูป : 
										<a href="<?php echo $objResult['img_path']; ?>"  >
                                            <img src="<?php echo $objResult['img_path']; ?>" alt="">
                                        </a>
								<input type="file" name="file_img" id="file_img" class="form-control"  aria-describedby="">
								
								<button name="btn_upload" type="submit" value="Submit" id="" class="btn btn-primary">
										ตกลง
								</button>

								
	
							</div> 
						</div> 
					</form>
								
								
					<?php
					mysqli_close($conn);
					?>     
					
				</div>
		
			</div>
		</div>
	
</body>
</html>