<html>
<head>
<title>ThaiCreate.Com Tutorial</title>


<link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css"> 
    <script src="js/bootstrap.min.js" integrity="" crossorigin="anonymous"></script>
</head>
<body>
<?php
		require "dbc.php";

		//*** Select Old File  ***//
		$strSQL = "SELECT * FROM tbl_photos3 WHERE img_id = '".$_GET["img_id"]."' ";
		$objQuery = mysqli_query($conn, $strSQL) or die ("Error Query [".$img_id."]");
		$objResult = mysqli_fetch_array($objQuery);
		
		//*** Delete Rows  ***//
		$strSQL = " DELETE FROM tbl_photos3 ";
		$strSQL .=" WHERE img_id = '".$_GET["img_id"]."' ";
		$objQuery = mysqli_query($conn, $strSQL);		
		

		echo "Delete Complete<br>";
		
		mysqli_close($conn);
?>

		<button name="back" type="submit" value="Submit" id="" class="btn btn-primary">
                            <a href="index.php" style="color: #ffff; text-decoration:none;">
                                กลับไปหน้าก่อน
                            </a>
                        </button>
</body>
</html>