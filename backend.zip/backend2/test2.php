<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>โปรแกรมคำนวนเงินทอน</title>
</head>
<body>
    <?php  
        $money = 0;
        $price = $_POST['price'];
        $moneyGat = $_POST['moneyGat'];
        $money = $moneyGat - $price ;
  
            if($money>=500){
                $sum1=$money/500;
                $sum1s=floor($sum1)*500;
                $money=$money-$sum1s;
                echo "มีจำนวนธนบัตร 500 = ".floor($sum1)." ใบ"."<br>";
            }if($money>=100){
                $sum2=$money/100;
                $sum2s=floor($sum2)*100;
                $money=$money-$sum2s;
                echo "มีจำนวนธนบัตร 100 = ".floor($sum2)." ใบ"."<br>";
            }if($money>=50){
                $sum3=$money/50;
                $sum3s=floor($sum3)*50;
                $money=$money-$sum3s;
                echo "มีจำนวนธนบัตร 50 = ".floor($sum3)." ใบ"."<br>";
            }if($money>=10){
                $sum4=$money/10;
                $sum4s=floor($sum4)*10;
                $money=$money-$sum4s;
                echo "มีจำนวนเหรียญ 10 = ".floor($sum4)." เหรียญ"."<br>";
            }if($money>=5){
                $sum5=$money/5;
                $sum5s=floor($sum5)*5;
                $money=$money-$sum5s;
                echo "มีจำนวนเหรียญ 5 = ".floor($sum5)." เหรียญ"."<br>";
            }if($money>=1){
                $sum6=$money/1;
                $sum6s=floor($sum6)*1;
                $money=$money-$sum6s;
                echo "มีจำนวนเหรียญ 1 = ".floor($sum6)." เหรียญ"."<br>";
            }
    
    ?>

</body>
</html>