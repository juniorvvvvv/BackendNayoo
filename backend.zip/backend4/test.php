<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>โปรแกรมคำนวนความคุ้ม</title>
</head>
<body>
    <?php  
        $money = $_POST['haveMoney']; 
        $itemSum = 0;
        $item1 =0;
        $price1 =25; 
        $item3  =0;
        $item2 =0;
        $price2 =30;

            echo "มีเงิน : $money <br>";  
            echo "---- <br>";
            // do{
            //     $m -= 25 ; //$m=$m-25
            //     $n++; 
            // }while($m>=25);
            //     echo "ทอนเงิน : $m <br>";
            //     echo "ซื้อได้ : $n <br>";
            //     echo "---- <br>";    
            $discount3 =  0;
            if(isset($price1)){
                $item = floor($money / $price1);      
                $item4 = $item * 25;
                $discount3 = $money - $item4;
                if($item<10){
                    echo "ซื้อร้านที่หนึ่ง 1 ได้ ".$item ." ชิ้น เหลือเงิน ".$discount3." บาท.<br>"; 
                   
                }
                if($item>=10){
                    // $discount = floor($money * 0.2);   //50
                    // $item2 = floor($discount / $price1);   //2
                    // $count = floor($discount * 0.2);
                    
                    // $itemSum = $item + $item2;

                    $c = $money - 200;
                
                    for($i=20; $i<=$c ; $i+=20){   
                        $item2 = $item2+1;
                        // echo  $i .  "<br>";
                      
                    }       
              
                    // echo   $item2  .  "<br>";
                    $int = $i-20;
                    // echo  $int .  "<br>";  
                    $discount1 = $c - $int;
                    $itemSum = $item + $item2;

                    echo "ซื้อร้านที่หนึ่ง 1 ได้ ".$itemSum ." ชิ้น เหลือเงิน ".$discount1." บาท<br>"; 
                    echo "---- <br>";

                }
            } 
         
            
            $itemGet = floor($money / $price2) ; //8

                for($i=3; $i<=$itemGet; $i+=3){   
                    $item3 = $item3+1;
                }           
                $item4 = $itemGet + $item3;
                $discount = $itemGet * $price2;
                $discount2 = $money - $discount;   
                    
                echo "ซื้อร้านที่หนึ่ง 2 ได้ ".$item4 ." ชิ้น เหลือเงิน ".$discount2." บาท<br>";
                echo "---- <br>";
                
                if($itemSum > $item4 ){
                    echo "แนะนำให้ซื้อร้านที่ 1 จะคุ้มที่สุด<br>";
                }
                else if($item > $item4 ){
                    echo "แนะนำให้ซื้อร้านที่ 1 จะคุ้มที่สุด.<br>";               
                }
                else if($itemSum == $item4  && $discount1 == $discount2 ){
                    echo "แนะนำให้ซื้อร้านไหนก็ได้<br>";
                }
                else if($item == $item4  && $discount3 == $discount2 ){
                    echo "แนะนำให้ซื้อร้านไหนก็ได้<br>";
                }
                else {
                    echo "แนะนำให้ซื้อร้านที่ 2 จะคุ้มที่สุด.<br>";
                }
    ?>

</body>
</html>